THIS PROJECT WAS MADE BY
RONALD NGODA
PHONE:+254708344101
EMAIL:ronniengoda@gmail.com
Website:ronaldngoda.rf.gd

--------------ABOUT THE PROJECT----------
This is an online bus ticket/booking system.With this system bus company owners can easily manage the bookings/reservations for seats in their buses.Company owners can manage bus routes,bus availability and list all the buses and seats.With this system customers cannot book for seats that have already been booked.Customers can not also do double reservation for eaxample if a customer has booked seat A10,DATE:today BUS:1 The same customer cannot also go and book SEAT A20:DATE:today BUS:1 same departure time.
Customers can only make reservations for buses and routes that are made available by admin or company management.This is to avoid confusions and enable proper planning and descition making.
The system admin can view summary reports of all and or fundamental activities within the system and be able to tell how the system is working from the rich insights from the summaries.
Customers can print receipts upon successfull booking and or can go to the booking agent to print the receipt and confirm payment.

--------INSTALLATION--------
After extracting the zip file in the root directory of your local server/online server
Go to the folder named INSTALL
Find a file named busbooking.sql
Go to phpmyadmin and create a database named busbooking
Import the file we named above busbooking.sql to create all the required tables for our system
After successfull import you can now use the system
==LOGIN DETAILS==
ADMIN
user:admin
pass:admin
==CUSTOMER==
create a new customer account using the sign up button on the login page!!!

ENJOY!!!!
FOR ANY QUESTIONS FEEL FREE TO CONTACT ME FROM THE ABOVE LISTED CONTACTS!!!
REGARDS
RONNIE THE PROGRAMMER!!